# Organoid fragment vs intact

Needs: python3, opencv-python, scikit-image, scikit-learn, scipy, numpy, joblib.

## Predict on new images
    python predict.py OUT_DIR img1.png img2.png ...
Writes `overlays/*.jpg`, `predictions.csv` (one row per object, with p_fragment and all features)
and `predictions_coco.json` (polygons in original pixel coordinates; import into Label Studio to correct).

Status per object:
- intact / fragment: classifier result (p_fragment > 0.5 = fragment)
- partial: touches the image edge, so shape can't be judged. Also catches dish-edge artefacts.
- out_of_focus: boundary too blurry to trust (focus < FOCUS_MIN, default 0.035; set env var to change)

## Retrain (e.g. after correcting 2024 predictions in Label Studio)
    python train_from_coco.py result.json /path/to/label-studio/media/upload/2
Overwrites frag_model.joblib and prints leave-one-image-out AUC.

## Pipeline
1. Lighting: resize to 1000 px wide, estimate illumination with a large grayscale closing
   (removes organoids, keeps vignette/dish edge as background), divide it out, mask regions darker than 55% of median.
2. Detection: threshold the flattened contrast at 0.16, fill/open, split touching objects with a distance-transform watershed,
   drop slivers and specks (beads).
3. Classification: logistic regression on 10 shape/texture features (circularity, convexity, ellipse fit, radial irregularity,
   texture variation, core/rim contrast, edge sharpness). Absolute brightness and size are deliberately excluded
   because they differ between 2023 and 2024 imaging.
